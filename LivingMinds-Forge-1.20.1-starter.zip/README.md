# Living Minds — Forge 1.20.1

Primeiro esqueleto do mod Living Minds para Minecraft Java 1.20.1 / Forge 47.2.0.

## O que já está nesta primeira etapa

- Projeto Gradle com ForgeGradle 6.
- Mod metadata para Forge 1.20.1.
- Catálogo inicial de personalidades para porco, vaca, ovelha, Creeper, zumbi, esqueleto, Enderman, raposa, gato e lobo.
- Ao interagir com um desses mobs de mão vazia, o jogador recebe uma fala de apresentação no chat.

## O que ainda NÃO está implementado

- Janela de conversa com campo de texto.
- IA generativa / conexão com API.
- Memória persistente.
- Níveis de relacionamento.
- Presentes e reações a alimentos favoritos.
- Conversas espontâneas e conversas entre mobs.
- Personalidades para todas as espécies.

Esses recursos serão desenvolvidos em etapas, testando cada uma antes de avançar.

## Requisitos

- JDK 17
- Minecraft Forge 1.20.1 (47.2.0)
- Gradle (o projeto usa o plugin ForgeGradle 6)

## Compilar

Em um computador com JDK 17 e Gradle configurados:

```bash
gradle build
```

O JAR compilado ficará em `build/libs/`.

## Observação sobre PojavLauncher

O PojavLauncher executa o jogo e os mods, mas não compila este projeto. O projeto precisa ser compilado em um ambiente de desenvolvimento compatível; depois, o arquivo JAR resultante pode ser testado no perfil Forge 1.20.1 do Pojav, se o dispositivo suportar as dependências e o desempenho necessários.
