package br.livingminds;

import br.livingminds.personality.PersonalityEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(LivingMinds.MOD_ID)
public class LivingMinds {
    public static final String MOD_ID = "livingminds";

    public LivingMinds() {
        MinecraftForge.EVENT_BUS.register(PersonalityEvents.class);
    }
}
