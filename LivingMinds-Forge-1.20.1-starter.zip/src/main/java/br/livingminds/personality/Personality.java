package br.livingminds.personality;

/**
 * Describes the conversational style assigned to a mob species.
 * Individual variation and persistent memories will be added in later milestones.
 */
public record Personality(
        String id,
        String displayName,
        String description,
        String greeting,
        String favoriteFoodReaction
) {}
