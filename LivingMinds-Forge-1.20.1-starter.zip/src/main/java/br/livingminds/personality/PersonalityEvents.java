package br.livingminds.personality;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Initial interaction hook. The first milestone only displays a short greeting
 * when the player interacts with a supported mob using an empty hand.
 */
public final class PersonalityEvents {
    private PersonalityEvents() {}

    @SubscribeEvent
    public static void onMobInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide()) {
            return;
        }

        Player player = event.getEntity();
        if (!(event.getTarget() instanceof LivingEntity mob)) {
            return;
        }

        if (!player.getMainHandItem().isEmpty()) {
            return;
        }

        PersonalityRegistry.get(mob.getType()).ifPresent(personality -> {
            player.sendSystemMessage(Component.literal(
                    personality.displayName() + ": \"" + personality.greeting() + "\""
            ));
        });
    }
}
