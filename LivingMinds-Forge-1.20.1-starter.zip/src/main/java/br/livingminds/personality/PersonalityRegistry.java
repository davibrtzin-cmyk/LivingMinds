package br.livingminds.personality;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Items;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * First-pass built-in personality catalogue for selected vanilla mobs.
 * This is intentionally data-driven in structure so more species can be added easily.
 */
public final class PersonalityRegistry {
    private static final Map<EntityType<?>, Personality> PERSONALITIES = new HashMap<>();

    static {
        register(EntityType.PIG, new Personality(
                "carrot_fanatic", "Porco",
                "Guloso, engraçado e completamente obcecado por cenouras.",
                "Você tem alguma cenoura aí? É uma pergunta muito importante.",
                "HMMMM! Esse barulho crocante... esse gosto angelical!"
        ));
        register(EntityType.COW, new Personality(
                "contemplative", "Vaca",
                "Tranquila e contemplativa; gosta de pensar sobre a vida.",
                "Às vezes me pergunto o que existe além deste pasto.",
                "Ah, trigo... um presente simples, mas cheio de significado."
        ));
        register(EntityType.SHEEP, new Personality(
                "gentle", "Ovelha",
                "Gentil, inocente e amigável.",
                "Olá! Hoje parece um ótimo dia para ficar no campo.",
                "Trigo! Você sabe como alegrar uma ovelha."
        ));
        register(EntityType.CREEPER, new Personality(
                "awkward", "Creeper",
                "Reservado e socialmente desajeitado; gostaria de fazer amigos.",
                "Oi... não precisa correr. Eu só queria conversar.",
                "Você está sendo... surpreendentemente gentil comigo."
        ));
        register(EntityType.ZOMBIE, new Personality(
                "confused", "Zumbi",
                "Confuso e desorientado; tenta entender o mundo.",
                "Hããã... que dia é hoje mesmo?",
                "Obrigado... acho que gostei disso."
        ));
        register(EntityType.SKELETON, new Personality(
                "sarcastic", "Esqueleto",
                "Sarcástico, irônico e provocador.",
                "Nossa, que surpresa. Um jogador. Nunca vi um antes.",
                "Um presente? Vou guardar isso junto da minha dignidade."
        ));
        register(EntityType.ENDERMAN, new Personality(
                "enigmatic", "Enderman",
                "Misterioso, inteligente e filosófico.",
                "Você mede o mundo em blocos. Já tentou medi-lo em escolhas?",
                "Interessante. Poucos oferecem algo sem exigir explicações."
        ));
        register(EntityType.FOX, new Personality(
                "clever", "Raposa",
                "Esperta, brincalhona e desconfiada.",
                "Eu não estava roubando nada. Estava apenas... investigando.",
                "Bagas doces? Talvez você seja menos previsível do que parece."
        ));
        register(EntityType.CAT, new Personality(
                "independent", "Gato",
                "Independente, elegante e um pouco arrogante.",
                "Pode falar. Tenho alguns segundos disponíveis.",
                "Um presente aceitável. Você pode continuar por perto."
        ));
        register(EntityType.WOLF, new Personality(
                "loyal", "Lobo",
                "Leal, protetor e carinhoso com quem conquistou sua confiança.",
                "Au! Estou aqui. O que vamos fazer hoje?",
                "Você cuidou de mim. Eu vou cuidar de você."
        ));
    }

    private PersonalityRegistry() {}

    private static void register(EntityType<?> type, Personality personality) {
        PERSONALITIES.put(type, personality);
    }

    public static Optional<Personality> get(EntityType<?> type) {
        return Optional.ofNullable(PERSONALITIES.get(type));
    }

    public static boolean hasPersonality(EntityType<?> type) {
        return PERSONALITIES.containsKey(type);
    }
}
